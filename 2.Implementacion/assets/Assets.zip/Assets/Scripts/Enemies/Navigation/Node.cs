using System.Collections.Generic;
using UnityEngine;

public class Node : MonoBehaviour
{
    [SerializeField] public Node cameFrom;
    [SerializeField] public List<Node> connections;
    
    //Costo real que tiene un camino (nº de nodos que van desde punto a a punto b)
    public float gScore;
    //Distancia heurística, es decir, el costo aproximado de la ruta, no es el valor exacto
    public float hScore; 

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    //suma de los dos costos. Nos quedaremos con la más baja, ya que será la más optima para el sistema
    public float fScore(){
        return gScore + hScore;
    }

//Utilizaremos este método para colorear lineas entre los nodos, y ver las conexiones entre ellos (Solo se ve en debug, no en ejecucoón)
    private void OnDrawGizmos(){
        Gizmos.color = Color.yellow;

        if(connections.Count > 0){
            for(int i = 0; i < connections.Count; i++){
                Gizmos.DrawLine(transform.position, connections[i].transform.position);
            }
        }
    }
}
