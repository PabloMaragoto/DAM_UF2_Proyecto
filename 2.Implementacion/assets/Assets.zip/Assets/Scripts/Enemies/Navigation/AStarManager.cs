using System.Collections.Generic;
using UnityEngine;

public class AStarManager : MonoBehaviour{
    static AStarManager instance;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Awake()
    {
        instance = this;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public static AStarManager GetAStarManager(){
        return instance;
    }

    //Creamos un método que se encargará de generar el camino, nuestro algoritmo A*. 
    //Como parámetrps debemos indicar el nodo de inicio y nodo de fin

    public List<Node> GeneratePath(Node start, Node end){

        //En esta lista guradararemos los nodos que tendremos que ir comprobando y explorando, para ver si pertenecen al camino generado
        List<Node> openSet = new List<Node>();

        //buscamos todos los nodos, y los inicializamos con una distancia real infinita (float.maxValue)
        foreach (Node n in NodesInScene())
        {
            n.gScore = float.MaxValue;
        }

        //En el punto de inicio, le decimos que hay una distancia de 0, ya que estamos en él y no hemos recoriddo ninguna distancia
        start.gScore = 0;
        //Calculamos la distancia heurística(aproximada) entre el punto de inicio y el punto final
        start.hScore = Vector2.Distance(start.transform.position,end.transform.position);
        //Añadimos el punto de inicio a la lista, para comenxar a explorarlo
        openSet.Add(start);

        //investigamos los nodos de la lista, mientras que esta no esté vacía
        while(openSet.Count > 0){
            //Guardamos el costo total más bajo, por ende, la ruta más optima, que es la que queremos
            int lowestF = default;

            //vamos comparando todos los costos de los nodos, y nos vamos qiuedando con el más bajo
            for (int i = 1; i < openSet.Count; i++){
                if (openSet[i].fScore() < openSet[lowestF].fScore()){
                    lowestF = i;
                } 
            }

            //Nos quedamos con el nodo que tenga la distancia más optima
            Node currentNode = openSet[lowestF];
            //Y lo quitamos de la lista de exploración
            openSet.Remove(currentNode);

            //Si el nodo es el nodo objetivo
            if(currentNode == end){
                //creamos una lista donde guardaremos los nodos que pertenecen al camino
                List<Node> path = new List<Node>();
                //insertamos primero el nodo final
                path.Insert(0,end);
                //Y mientras el nodo actual no sea el nodo inicial, vamos mirando de donde proviene y lo añadimos al camino
                while(currentNode != start){
                    currentNode = currentNode.cameFrom;
                    path.Add(currentNode);
                }
                //Una vez añadidos, invertimos la lista para que el camino vaya del punto de inicio al punto final
                path.Reverse();
                //lo devovlemos
                return path;
            }

            //Verificamos los nodos adyacentes del nodo actual (los que nosotros añadimos a su lista de conexiones)
            foreach (Node connectedNode in currentNode.connections){
                //Calculamos la distancia que nos llevaria ir a su adyacente desde el punto inicila,pasando por el nodo actual
                float heldGScore = currentNode.gScore + Vector2.Distance(currentNode.transform.position,connectedNode.transform.position);

                //verificamos si cuesta menos llegar al nodo adyacente pasando por el nodo actual
                if(heldGScore < connectedNode.gScore){
                    //En caso de que si, actualizamos los valores, como el nodo desde el que llegamos
                    connectedNode.cameFrom = currentNode;
                    //La distancia real que ahora cuesta
                    connectedNode.gScore = heldGScore;
                    //la nueva distancia heurística
                    connectedNode.hScore = Vector2.Distance(connectedNode.transform.position,end.transform.position);

                    //Lo añadimos a la lista de exploración en caso de que no estuviese ya
                    if(!openSet.Contains(connectedNode)){
                        openSet.Add(connectedNode);
                    }
                }
            }
        }
        return null;
    }

    public Node FindNearestNode(Vector2 position){

        Node foundNode = null;
        float minDistance = float.MaxValue;

        foreach (Node node in NodesInScene())
        {
            float currentDistance = Vector2.Distance(position, node.transform.position);
            if(currentDistance < minDistance){
                minDistance = currentDistance;
                foundNode = node;
            }
        }
        return foundNode;
    }

    public Node FindFurthestNode(Vector2 position){

        Node foundNode = null;
        float maxDistance = 0;

        foreach (Node node in NodesInScene())
        {
            float currentDistance = Vector2.Distance(position, node.transform.position);
            if(currentDistance > maxDistance){
                maxDistance = currentDistance;
                foundNode = node;
            }
        }
        return foundNode;
    }

    public Node[] NodesInScene(){
        return FindObjectsByType<Node>(FindObjectsSortMode.None);
    }
}
