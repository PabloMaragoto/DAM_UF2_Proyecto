using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class NPCController : MonoBehaviour
{
    public Node currentNode;
    public List<Node> path = new List<Node>();

    [SerializeField] float speed;
    [SerializeField] float distanceSeen;
    public MyCharacterController player;

    Node[] nodes;
    AStarManager aStarManager;

    public enum StateMachine{
        Patrol,
        Engage
    }

    public StateMachine currentState;

    void Start()
    {
        currentState = StateMachine.Patrol;
        aStarManager = AStarManager.GetAStarManager();
        nodes = AStarManager.GetAStarManager().NodesInScene();
        currentNode = aStarManager.FindNearestNode(transform.position);
    }

    void Update()
    {
        switch (currentState)
        {
            case StateMachine.Patrol:
                Patrol();
                break;
            case StateMachine.Engage:
                Engage();
                break;
        }

        bool playerSeen = Vector2.Distance(transform.position, player.transform.position) < distanceSeen;

        StateMachine newState = playerSeen ? StateMachine.Engage : StateMachine.Patrol;

        if (newState != currentState){
            currentState = newState;
            path.Clear();
        }

        switch (currentState){
            case StateMachine.Patrol: Patrol(); break;
            case StateMachine.Engage: Engage(); break;
        }

        CreatePath();
    }

    void Patrol(){
        if(path.Count == 0){
            path = aStarManager.GeneratePath(currentNode, nodes[Random.Range(0, nodes.Length)]);
        }
    }

    void Engage(){
        if(path.Count == 0){
            path = aStarManager.GeneratePath(currentNode, aStarManager.FindNearestNode(player.transform.position));
        }
    }

    void CreatePath(){
        if(path.Count > 0){
            
            transform.position = Vector2.MoveTowards(transform.position, new Vector3(path[0].transform.position.x, path[0].transform.position.y), speed * Time.deltaTime);

            if(Vector2.Distance(transform.position, path[0].transform.position) == 0){
                currentNode = path[0];
                path.RemoveAt(0);
            }
        }
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.CompareTag("Player")){
            collision.gameObject.transform.position = Vector3.zero;
            path.Clear();
            GameObject spawn = GameObject.FindGameObjectWithTag("Spawn");
            transform.position = spawn.transform.position;
            currentNode = spawn.GetComponent<Node>();
        }
    }
}
