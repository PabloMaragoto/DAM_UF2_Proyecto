using System.Collections;
using UnityEngine;

public class BulletSpawner : MonoBehaviour
{
    [SerializeField] GameObject bullet;
    [SerializeField] float interval;
    [SerializeField] float delay;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        StartCoroutine("BulletSpawn");
        
    }

    IEnumerator BulletSpawn(){
        yield return new WaitForSeconds(delay);
        while(true){
            Vector3 position = new Vector3(transform.position.x,Random.Range(gameObject.GetComponent<SpriteRenderer>().bounds.min.y, gameObject.GetComponent<SpriteRenderer>().bounds.max.y), 0);
            Instantiate(bullet, position, Quaternion.identity);
            yield return new WaitForSeconds(delay);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
