using System.Collections;
using UnityEngine;

public class SpawnerTargets : MonoBehaviour
{
    [SerializeField] GameObject enemy;
    [SerializeField] GameObject fakeTarget;
    [SerializeField] float initialSpawnInterval = 2f;
    [SerializeField] CountDownTimer timer;  
    float timeLeft;

    private bool isSpawning = true;          

    // Start is called once before the first frame update
    void Start()
    {
        StartCoroutine("SpawnTarget"); 
    }

    // Update is called once per frame
    void Update()
    {
        timeLeft = timer.GetTimeLeft();
    }

    IEnumerator SpawnTarget()
    {

        while(isSpawning){
            GameObject spawnObject = Random.Range(0, 2) == 1 ? enemy : fakeTarget;

            float spawnInterval = timeLeft <= 30 ? 0.5f :
                                  timeLeft <= 60 ? 1.0f : initialSpawnInterval;

            Vector3 position = new Vector3(Random.Range(gameObject.GetComponent<SpriteRenderer>().bounds.min.x, gameObject.GetComponent<SpriteRenderer>().bounds.max.x),
                                           Random.Range(gameObject.GetComponent<SpriteRenderer>().bounds.min.y, gameObject.GetComponent<SpriteRenderer>().bounds.max.y), 0);

            Instantiate(spawnObject, position, Quaternion.identity);
            yield return new WaitForSeconds(spawnInterval);
        }
    }
}
