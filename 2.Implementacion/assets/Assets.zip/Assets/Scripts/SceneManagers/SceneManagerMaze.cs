using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneManagerMaze : MonoBehaviour
{
    public static SceneManagerMaze instance { get; private set; } = null;
    [SerializeField] TMP_Text numberCoinsText;
    public float numberCoins{ get; private set; } = 0;

    [SerializeField] GameObject panelInstructions;
    [SerializeField] GameObject panelFinish;
    [SerializeField] GameObject panelCoins;
    [SerializeField] GameObject enemy;
    [SerializeField] GameObject player;

    void Awake()
    {
        if(instance != null){
            Destroy(gameObject);
        }else{
            instance = this;
        }
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        GameObject[] coins = GameObject.FindGameObjectsWithTag("Collectable_Coin");

        numberCoins = coins.Length;

        numberCoinsText.text = numberCoins.ToString();
    }

    // Update is called once per frame
    void Update()
    {
        if(numberCoins == 0){
            ShowEndingRoom();
        }
    }

    public void FindCoin(){
        numberCoins--;
        numberCoinsText.text = numberCoins.ToString();
    }

    public void HideInstructions(){

        if (panelInstructions != null){
            panelInstructions.SetActive(false); 
        }
        StartCoroutine(ActivateGame(1f));
    }

    private IEnumerator ActivateGame(float delay){
        yield return new WaitForSeconds(delay);
            enemy.SetActive(true);
            player.GetComponent<MyCharacterController>().enabled = true; 
            panelCoins.SetActive(true);
    }

    public void ShowEndingRoom(){
        enemy.SetActive(false);
        player.GetComponent<MyCharacterController>().enabled = false; 
        panelCoins.SetActive(false);
        panelFinish.SetActive(true);
        GameManager.instance.SceneHasBeenCompleted(SceneManager.GetActiveScene().buildIndex);
        GameManager.instance.MazeRoomDone();
    }

    public void Return(){
        if(GameManager.instance.GetIsRunnerRoomDone() && GameManager.instance.GetIsShootingRoomDone() ){
            SceneManager.LoadScene(6);
        }else{
            SceneManager.LoadScene(1);
        }
    }
}
