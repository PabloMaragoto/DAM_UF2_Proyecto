using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneManagerRunnerRoom : MonoBehaviour
{
    public static SceneManagerRunnerRoom instance { get; private set; } = null;
    const int LIVES = 3;
    [SerializeField] GameObject[] imgLives;
    [SerializeField] GameObject timer;
    [SerializeField] GameObject spawnerObstacles;
    [SerializeField] GameObject spawnerBullets;
    [SerializeField] GameObject player;
    [SerializeField] GameObject panelInstructions;

    [SerializeField] GameObject panelVictory;
    [SerializeField] GameObject panelJumpscare;

    [SerializeField] AudioSource myAudioSource;
    [SerializeField] AudioClip jumpscare;
    int lives = LIVES;

    void Awake()
    {
        if(instance != null){
            Destroy(gameObject);
        }else{
            instance = this;
        }
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        OnGUI();

        if(timer.GetComponent<CountDownTimer>().GetTimeLeft() == 0 || lives == 0){
            FinishGame();
        }
    }

    private void OnGUI() {
       for(int i=0; i<imgLives.Length; i++){
            imgLives[i].SetActive(i<lives); 
        }
    }

    public void ReceiveDamage(){
        lives--;
    }

    public void HideInstructions(){

        if (panelInstructions != null){
            panelInstructions.SetActive(false); 
        }
        StartCoroutine(ActivateGame(1f));
    }

    private IEnumerator ActivateGame(float delay){
        yield return new WaitForSeconds(delay);
            spawnerBullets.SetActive(true);
            player.GetComponent<MyCharacterController>().enabled = true; 
            spawnerObstacles.SetActive(true);
            timer.SetActive(true);
    }

    void FinishGame(){
        if(lives > 0){
            GameManager.instance.RunnerRoomDone();
            GameManager.instance.SceneHasBeenCompleted(SceneManager.GetActiveScene().buildIndex);
            panelVictory.SetActive(true);
        }else{
            myAudioSource.Stop();
            myAudioSource.clip = jumpscare;
            ActivateJumpscare();
        }
    }

    void ActivateJumpscare(){
        panelJumpscare.SetActive(true);
        myAudioSource.Play();
        Invoke("ReturnToScene", 3f);
    }

    public void ReturnToScene(){
        if(GameManager.instance.GetIsMazeRoomDone() && GameManager.instance.GetIsShootingRoomDone() && GameManager.instance.GetIsRunnerRoomDone()){
            SceneManager.LoadScene(6);
        }else{
            SceneManager.LoadScene(1);
        }
    }
}
