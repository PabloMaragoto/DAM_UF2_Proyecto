using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;

public class SceneManagerShootingRoom : MonoBehaviour
{
    public static int enemiesDestroyed { get; private set; } = 0;
    public static int targetsDestroyed { get; private set; } = 0;
    const int MIN_POINTS = 25;
    [SerializeField] GameObject panelInstructions;
    [SerializeField] GameObject scores;
    [SerializeField] GameObject results;
    [SerializeField] GameObject spawner;
    [SerializeField] GameObject timer;

    [SerializeField] GameObject time;
    [SerializeField] TMP_Text enemies;
    [SerializeField] TMP_Text targets;
    [SerializeField] TMP_Text totalScore;

    [SerializeField] TMP_Text result;
    [SerializeField] TMP_Text message;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if(timer.GetComponent<CountDownTimer>().GetTimeLeft() == 0){
            FinishGame();
        }
    }

    public static void EnemyHit(){
        enemiesDestroyed++;
    }

    public static void TargetHit(){
        targetsDestroyed++;
    }

    public void HideInstructions(){

        if (panelInstructions != null){
            panelInstructions.SetActive(false); 
        }
        StartCoroutine(ActivateSpawner(3f));
    }

    private IEnumerator ActivateSpawner(float delay){
        yield return new WaitForSeconds(delay);
        if (spawner != null){
            timer.SetActive(true);
            spawner.SetActive(true); 
            time.SetActive(true);
        }
    }

    void FinishGame(){
        spawner.SetActive(false);
        timer.SetActive(false);
        time.SetActive(false);
        Destroy(GameObject.FindWithTag("Enemy"));
        Destroy(GameObject.FindWithTag("FakeTarget"));
        enemies.text = enemiesDestroyed.ToString();
        targets.text = targetsDestroyed.ToString();
        totalScore.text = GetTotalScore().ToString();
        scores.SetActive(true);
    }

    int GetTotalScore(){
        return (enemiesDestroyed - targetsDestroyed);
    }

    public void SeeResults(){

        int score = GetTotalScore();

        if(score > MIN_POINTS){
            result.text = "¡Has ganado!";
            message.text = "Consigues una piedra del alma.";
            GameManager.instance.SceneHasBeenCompleted(SceneManager.GetActiveScene().buildIndex);
            GameManager.instance.ShootingRoomDone();
        }else{
            result.text = "¡Has perdido!";
            message.text = "Necesitas al menos conseguir " + MIN_POINTS.ToString();
        }
        scores.SetActive(false);

        results.SetActive(true);
    }

    public void Return(){
        if(GameManager.instance.GetIsRunnerRoomDone() && GameManager.instance.GetIsMazeRoomDone() ){
            SceneManager.LoadScene(6);
        }else{
            SceneManager.LoadScene(1);
        }
    }

}
