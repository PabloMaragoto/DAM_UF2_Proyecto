using UnityEngine;

public class SceneManagerLobby : MonoBehaviour
{
    [SerializeField] GameObject gemRed;
    [SerializeField] GameObject gemBlue;
    [SerializeField] GameObject gemPurple;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        if(GameManager.instance.IsSceneCompleted(3)){
            gemBlue.SetActive(true);
        }

        if(GameManager.instance.IsSceneCompleted(4)){
            gemPurple.SetActive(true);
        }

        if(GameManager.instance.IsSceneCompleted(5)){
            gemRed.SetActive(true);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
