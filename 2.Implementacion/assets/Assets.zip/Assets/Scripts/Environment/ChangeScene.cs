using UnityEngine;
using UnityEngine.SceneManagement;

public class ChangeScene : MonoBehaviour
{
    [SerializeField] int numberScene;
    [SerializeField] GameObject keyCodeE;
    bool isPlayerInside ;

    void Start()
    {
        if(GameManager.instance.IsSceneCompleted(numberScene)){
            gameObject.SetActive(false);
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerStay2D(Collider2D collision)
    {
        if(isPlayerInside && Input.GetKey(KeyCode.E)){
            SceneManager.LoadScene(numberScene);
        }
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag.Equals("Player")){
            keyCodeE.SetActive(true);
            isPlayerInside = true;
        }
    }

    void OnTriggerExit2D(Collider2D collision)
    {
        if(collision.gameObject.tag.Equals("Player")){
            keyCodeE.SetActive(false);
            isPlayerInside = false;
        }
    }

}
