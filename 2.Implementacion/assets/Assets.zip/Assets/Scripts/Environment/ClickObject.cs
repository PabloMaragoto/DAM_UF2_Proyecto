using System.Threading;
using UnityEngine;

public class ClickObject : MonoBehaviour
{
    [SerializeField] GameObject explosionPrefab;
    [SerializeField] AudioClip clip; 

    void Start(){
        Destroy(gameObject, 5f);
    }

    void OnMouseDown()
    {
        if(gameObject.tag.Equals("Enemy")){
            SceneManagerShootingRoom.EnemyHit();
        }else if(gameObject.tag.Equals("FakeTarget")){
            SceneManagerShootingRoom.TargetHit();
        }

        if (explosionPrefab != null){
            GameObject explosion = Instantiate(explosionPrefab, transform.position, Quaternion.identity);
            AudioSource audioSource = explosion.GetComponent<AudioSource>();
            audioSource.clip = clip;
            audioSource.Play();
            Destroy(explosion, 1f); 
        }

        Destroy(gameObject);
    }
}
