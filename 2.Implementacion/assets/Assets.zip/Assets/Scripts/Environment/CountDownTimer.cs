using TMPro;
using UnityEngine;

public class CountDownTimer : MonoBehaviour
{
    [SerializeField] TMP_Text textTimer;
    [SerializeField]  float totalTime;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (totalTime > 0){
            totalTime -= Time.deltaTime;
        }else{
            totalTime = 0;
        }
        float minutes = Mathf.FloorToInt(totalTime / 60);  
        float seconds = Mathf.FloorToInt(totalTime % 60);

        textTimer.text = string.Format("{0:00}:{1:00}", minutes, seconds);

        if (totalTime <= 15){
            textTimer.color = Color.red;
        }else if (totalTime <= 30){
            textTimer.color = Color.yellow;
        }else{
            textTimer.color = Color.white;
        }
    }

    public float GetTimeLeft(){
        return totalTime;
    }
}
