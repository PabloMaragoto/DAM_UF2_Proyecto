using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{

    public static GameManager instance { get; private set; }

    List<int> scenesCompleted = new List<int>();

    [SerializeField] bool isMazeRoomDone;
    [SerializeField] bool isRunnerRoomDone;
    [SerializeField] bool isShootingRoomDone;

    public bool estaEnPausa;
    public GameObject menuPausa;

    void Awake()
    {
        if(instance != null){
            Destroy(gameObject);
        }else{
            instance = this;
            DontDestroyOnLoad(gameObject);
        }
    }

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown (KeyCode.Escape)){
            if(estaEnPausa){
                menuPausa.SetActive(false);
                Time.timeScale = 1.0f;
                estaEnPausa = false;
            }else{
                menuPausa.SetActive(true);
                Time.timeScale = 0.0f;
                estaEnPausa = true;
            }
        }
    }

    public void SceneHasBeenCompleted(int sceneIndex){
        scenesCompleted.Add(sceneIndex);
    }

    public bool IsSceneCompleted(int sceneIndex){
        
        return scenesCompleted.Contains(sceneIndex);
    }

    public void MazeRoomDone(){
        isMazeRoomDone = true;
    }

    public void ShootingRoomDone(){
        isShootingRoomDone = true;
    }

    public void RunnerRoomDone(){
        isRunnerRoomDone = true;
    }

    public void ExitGame(){
        Application.Quit();
    }

    public bool GetIsMazeRoomDone(){
        return isMazeRoomDone;
    }

    public bool GetIsRunnerRoomDone(){
        return isRunnerRoomDone;
    }

    public bool GetIsShootingRoomDone(){
        return isShootingRoomDone;
    }

    public void ResetGame(){
        isMazeRoomDone = false;
        isRunnerRoomDone = false;
        isShootingRoomDone = false;
    }


}
