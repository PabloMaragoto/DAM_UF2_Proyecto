using UnityEngine;

public class MyCharacterController : MonoBehaviour
{

    [SerializeField] float speed;
    [SerializeField] bool movementHorizontal;
    
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {

        float verticalInput = Input.GetAxis("Vertical");
        float horizontalInput = Input.GetAxis("Horizontal");

        if (horizontalInput != 0 && movementHorizontal) {
            transform.Translate(Vector3.right * horizontalInput * speed * Time.deltaTime);
        }

        if (verticalInput != 0) {
            transform.Translate(Vector3.up * verticalInput * speed * Time.deltaTime);
        }
    }
}
